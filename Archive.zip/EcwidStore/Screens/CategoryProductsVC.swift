//
//  CategoryProductsVC.swift
//  EcwidStore
//
//  Created by Logista on 7/27/20.
//  Copyright © 2020 Logista. All rights reserved.
//

import UIKit

class CategoryProductsVC: DataLoadingVC {

    let mainTitle = UILabel()
    let subTitle = UILabel()
    var collectionView:UICollectionView!
    
    var items = [PItem]()
    var category:StoreCategory?
    var productsIDs:[Int] = [Int]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setCollectionView()
        setTitles()
        layoutUI()
        view.backgroundColor = .white
        self.navigationItem.leftBarButtonItem = UIBarButtonItem(barButtonSystemItem: .cancel, target: self, action: #selector(DismissSelf))
        getProducts()
    }
    
    override func viewWillAppear(_ animated: Bool) {
           super.viewWillAppear(animated)
           self.collectionView.reloadDataOnMainThread()
        self.mainTitle.text = self.category?.name ?? ""
        self.subTitle.text = self.category?.name ?? ""
       }
    
    func getProducts(){
        if self.productsIDs.count > 0 {
        items.removeAll()
        self.collectionView.reloadDataOnMainThread()
        showLoadingView()
        StoreClient.shared.getSubCategory(for: productsIDs) { (result) in
            switch result {
            case .failure(let error):
                print(error)
            case .success(let product):
                for item in product.items{
                    if item.enabled {
                        self.items.append(item)
                    }
                }
                self.dismissLoadingView()
                self.collectionView.reloadDataOnMainThread()
            }
        }
    }
    }
    
    func setTitles(){
        mainTitle.font = UIFont.systemFont(ofSize: 25, weight: .bold)
        mainTitle.textColor = .black
        mainTitle.textAlignment = .left
        mainTitle.numberOfLines = 2
        mainTitle.translatesAutoresizingMaskIntoConstraints = false
        
        subTitle.font = UIFont.systemFont(ofSize: 16, weight: .light)
        subTitle.textColor = .gray
        subTitle.textAlignment = .left
        subTitle.numberOfLines = 1
        subTitle.translatesAutoresizingMaskIntoConstraints = false
    }
    
    func setCollectionView(){
        collectionView = UICollectionView(frame: view.bounds, collectionViewLayout: UIHelper.getTwoCellsFlowLayout(in: self.view))
        collectionView.register(CardCell.self, forCellWithReuseIdentifier: CardCell.reuseID)
        collectionView.backgroundColor = .white
        collectionView.translatesAutoresizingMaskIntoConstraints = false
        collectionView.dataSource = self
        collectionView.delegate = self
    }
    
    func layoutUI(){
        view.addSubViews(mainTitle,subTitle,collectionView)
        
        NSLayoutConstraint.activate([
            mainTitle.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 0),
            mainTitle.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 8),
            mainTitle.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -8),
            mainTitle.heightAnchor.constraint(equalToConstant: 60),
            
            subTitle.topAnchor.constraint(equalTo: mainTitle.bottomAnchor, constant: 0),
            subTitle.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 8),
            subTitle.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -8),
            subTitle.heightAnchor.constraint(equalToConstant: 20),
            
            collectionView.topAnchor.constraint(equalTo: subTitle.bottomAnchor, constant: 8),
            collectionView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            collectionView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            collectionView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
    }
    
    @objc func DismissSelf(){
        dismiss(animated: true)
    }
    
}
extension CategoryProductsVC: UICollectionViewDelegate , UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        self.items.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: CardCell.reuseID, for: indexPath) as! CardCell
        cell.set(with: self.items[indexPath.item])
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let vc = SingleProductVC()
//        vc.modalPresentationStyle = .fullScreen
        vc.item = self.items[indexPath.item]
        self.present(vc,animated: true)
    }
    
}
